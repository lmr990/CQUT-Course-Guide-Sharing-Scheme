# -*- coding: utf-8 -*-
# =========================================================================
# 5_05  表格数据求累积积分，再对积分结果插值，取任意时刻的值
#       先积分得 s(t)，再用 lagrange(t, s, t_new) 查任意时刻
#   题目关键词：由数据表求积分 / 求某时刻的累积量 / 积分后再插值
# =========================================================================
import numpy as np
from scipy.integrate import simps
from lagrange1 import lagrange
import matplotlib.pyplot as plt

t = np.array([0, 5, 10, 15, 20, 25, 30, 35, 40, 45, 50, 55, 60, 65, 70, 75, 80, 85, 90])  # 【改：换成题目给的自变量数据】
pA = np.array([0, 19, 52, 55, 48, 48, 35, 44, 66, 78, 89, 95, 98, 75, 64, 74, 84, 84, 74])  # 【改：换成题目给的被积数据】
u = len(t)
s = np.zeros_like(t)
for i in range(u):
    s[i] = simps(pA[0:i+1]/3.6, t[0:i+1])                                   # 【改：/3.6 是单位换算，题目没要求就删掉；新版 scipy 要把 simps 写成 simpson】
plt.plot(t, s, '-.')
t_new=3                                                                     # 【改：换成题目问的那个时刻】
s_new=lagrange(t,s,t_new)                                                   # 【不用改：对积分结果做拉格朗日插值】
print('s_new:',s_new)
