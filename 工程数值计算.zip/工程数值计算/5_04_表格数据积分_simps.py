# -*- coding: utf-8 -*-
# =========================================================================
# 5_04  表格数据求累积积分（scipy 的 simps，新版 scipy 改叫 simpson）
#       逐个前缀积分 s[i] = ∫(t0→t_i) pA dt，得到累积量曲线
#   题目关键词：由数据表求积分 / 求累积量 / 辛普森积分 / 出口累积量 / 反应量
# =========================================================================
import numpy as np
from scipy.integrate import simps
import matplotlib.pyplot as plt

t = np.array([0, 5, 10, 15, 20, 25, 30, 35, 40, 45, 50, 55, 60, 65, 70, 75, 80, 85, 90])  # 【改：换成题目给的自变量数据】
pA = np.array([0, 19, 52, 55, 48, 48, 35, 44, 66, 78, 89, 95, 98, 75, 64, 74, 84, 84, 74])  # 【改：换成题目给的被积数据】
u = len(t)
s = np.zeros_like(t)
for i in range(u):
    s[i] = simps(pA[0:i+1]/3.6, t[0:i+1])                                   # 【改：/3.6 是单位换算，题目没要求就删掉；新版 scipy 要把 simps 写成 simpson】
    i+=1
plt.plot(t, s, '-.')
plt.show()
