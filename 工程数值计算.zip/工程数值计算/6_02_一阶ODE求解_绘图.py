# -*- coding: utf-8 -*-
# =========================================================================
# 6_02  一阶常微分方程初值问题（solve_ivp + 作 y-t 图）
#       与 6_01 完全相同，只是多画了曲线
#   题目关键词：一阶常微分方程 / 初值问题 / 作 y-t 图 / 解的曲线
# =========================================================================
import numpy as np
from scipy.integrate import solve_ivp
import matplotlib.pyplot as plt

def f(t,y):
    return (y*y+2*y-2)/(y+1)                            # 【改：return 后面换成题目给的右端函数 f(t, y)】

sol=solve_ivp(f,(0,2),[2],t_eval=np.linspace(0,2,100))  # 【改：(0,2) 换成题目给的 t 区间，[2] 换成初值 y0，linspace 的端点要跟区间一致】
print(sol.t)
print(sol.y)
plt.plot(sol.t,sol.y[0])
