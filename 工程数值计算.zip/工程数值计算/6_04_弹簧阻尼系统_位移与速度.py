# -*- coding: utf-8 -*-
# =========================================================================
# 6_04  弹簧-阻尼系统：solve_ivp 求位移 s 与速度 v
#       m·s'' = F - c·s' - k·s，降阶为 [s', v'] = [v, (F - cv - ks)/m]
#   题目关键词：弹簧阻尼系统 / 二阶常微分方程 / 振动 / 求位移和速度
# =========================================================================
import numpy as np
from scipy.integrate import solve_ivp
import matplotlib.pyplot as plt

def f(t,y):
    F=5;m=5;c=3;k=50                                         # 【改：换成题目给的外力 F / 质量 m / 阻尼 c / 刚度 k】
    return np.array([y[1],
                     F/m-c/m*y[1]-k/m*y[0]])                 # 【与上一行合起来是方程组 [s', v']，按题目给的方程改】

sol=solve_ivp(f,(0,20),[0,0],t_eval=np.linspace(0,20,1000))  # 【改：(0,20) 换成题目给的时间区间，[0,0] 换成初值 [s0, v0]，linspace 的两个端点要跟区间一致】
plt.plot(sol.t,sol.y[0],sol.t,sol.y[1],'--')
plt.legend(['s','v'])
