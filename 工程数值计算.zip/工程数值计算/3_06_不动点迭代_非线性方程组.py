# -*- coding: utf-8 -*-
# =========================================================================
# 3_06  不动点（Jacobi）迭代解非线性方程组（迭代框架，供 3_07 调用，本身不用改）
#       x(k+1) = g(x(k))；max|x(k+1) - x(k)| < eps 停止
#   题目关键词：不动点迭代 / 简单迭代法 / 迭代法解非线性方程组 / 收敛性
# =========================================================================
import numpy as np

def jacbi(g, x0, args=(), eps=1e-9, max_iter=100):  # 【照抄：迭代框架，不用改。要改的题目数据在 3_07 里】
    for n_iter in range(max_iter):
        x = x0.copy()
        x0 = g(x0, *args)                           # 【迭代式 x(k+1)=g(x(k))，答卷照抄这行】
        diff = np.max(np.abs(x - x0))
        if diff < eps:
            break
    else:
        print('The accuracy is not achieved')
    return x0, n_iter + 1
