# -*- coding: utf-8 -*-
# =========================================================================
# 5_07  弹簧-阻尼系统：solve_ivp 求位移与速度，再中心差分求加速度（自带差分函数）
#       m·s'' = F - c·s' - k·s；加速度 = (v(i+1)-v(i-1))/(t(i+1)-t(i-1))
#   题目关键词：弹簧阻尼系统 / 二阶常微分方程 / 求位移速度加速度 / 振动 / 中心差分
# =========================================================================
import numpy as np
from scipy.integrate import solve_ivp
import matplotlib.pyplot as plt

def differential(t_array, y_array, h, t_new):                               # 【不用改：中心差分求导函数，与 5_01 只是写法不同】
    """
    数值微分：dy/dt，中心差分公式
    t_array: 全部时间点数组 sol.t
    y_array: 待求导的数组（这里是速度v）
    h: 微小时间步长
    t_new: 当前要计算导数的时刻
    """
    # 找到t_new对应的索引
    idx = np.argmin(np.abs(t_array - t_new))
    
    # 中心差分
    if 0 < idx < len(t_array)-1:
        deriv = (y_array[idx+1] - y_array[idx-1]) / (t_array[idx+1] - t_array[idx-1])  # 【中心差分公式，答卷照抄这行】
    else:
        # 边界点：向前差分
        if idx == 0:
            deriv = (y_array[idx+1] - y_array[idx]) / (t_array[idx+1] - t_array[idx])
        # 最后一点：向后差分
        else:
            deriv = (y_array[idx] - y_array[idx-1]) / (t_array[idx] - t_array[idx-1])
    return deriv


# ========== 主程序 ==========
def f(t,y):
    F=5;m=5;c=3;k=50                                                        # 【改：换成题目给的外力 F / 质量 m / 阻尼 c / 刚度 k】
    return np.array([y[1],
                     F/m - c/m*y[1] - k/m*y[0]])                            # 【与上一行合起来是方程组 [s', v']，按题目给的方程改】

sol = solve_ivp(f,(0,20),[0,0],t_eval=np.linspace(0,20,1000))               # 【改：(0,20) 换成题目给的时间区间，[0,0] 换成初值 [s0, v0]，linspace 的两个端点要跟区间一致】
h=0.001
i=0
a=np.zeros_like(sol.t)
for t_new in sol.t:
    a[i] = differential(sol.t, sol.y[1], h, t_new)
    i += 1

plt.plot(sol.t,sol.y[0],sol.t,sol.y[1],'-.',sol.t,a,'--')
plt.legend(['s','v','a'])
plt.show()
