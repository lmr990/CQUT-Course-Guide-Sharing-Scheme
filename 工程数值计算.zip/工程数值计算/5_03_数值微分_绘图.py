# -*- coding: utf-8 -*-
# =========================================================================
# 5_03  由数据表求导数并画图（调用 5_01 的 differential）
#       同时画出导数曲线与原始数据曲线
#   题目关键词：数值微分 / 求变化率并作图 / 反应速率曲线
# =========================================================================
import numpy as np
from differential1 import differential
import matplotlib.pyplot as plt

t = np.array([0, 5, 10, 15, 20, 25, 30, 35, 40, 45, 50, 55, 60, 65, 70, 75, 80, 85, 90])  # 【改：换成题目给的自变量数据】
pA = np.array([0, 19, 52, 55, 48, 48, 35, 44, 66, 78, 89, 95, 98, 75, 64, 74, 84, 84, 74])  # 【改：换成题目给的函数值数据】
h = 0.001                                                                   # 【步长，一般不用改】
i = 0
dp = np.zeros_like(t)
print('t dpA/dt')
for t_new in t:
    dpA = differential(t, pA, h, t_new)
    print(t_new, dpA)
    dp[i] = dpA
    i += 1
plt.plot(t, dp, '-', t, pA, '--')
plt.show()
