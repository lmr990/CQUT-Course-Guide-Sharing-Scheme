# -*- coding: utf-8 -*-
# =========================================================================
# 3_09  不动点迭代解非线性方程组（scipy 版，用默认的 Aitken 加速）
#       与 3_08 内容相同，区别是这里没写 method，走默认的 del2/Aitken 加速
#   题目关键词：不动点迭代 / scipy 解非线性方程组 / 埃特金加速 / Aitken
# =========================================================================
import numpy as np
from scipy import optimize as spopt

def g(x):
    g0 = (11 - x[1] * x[1] - x[2]) / 10  # 【改：g 的第 1 个分量，用题目给的式子】
    g1 = (18 - x[0] - x[2] * x[2]) / 10  # 【改：g 的第 2 个分量】
    g2 = (15 - x[0] * x[0] - x[1]) / 10  # 【改：g 的第 3 个分量】
    return np.array([g0, g1, g2])

x0 = np.array([1,1,1])                   # 【改：初值向量】
x = spopt.fixed_point(g, x0)             # 【想算得稳就补上 method='iteration'（照 3_08 改）】
print('Result with del2:',x)
