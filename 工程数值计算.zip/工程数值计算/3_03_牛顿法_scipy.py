# -*- coding: utf-8 -*-
# =========================================================================
# 3_03  牛顿法求非线性方程的根（scipy 版）
#       newton(f, x0, fprime=df)；不写 fprime 就自动改用割线法，那时必须再传 x1
#   题目关键词：牛顿法 / 牛顿迭代法 / 切线法 / 求方程的根 / scipy 求根
# =========================================================================
import numpy as np
from scipy.optimize import newton

def f(x):
    return 2**(x*x) - 10*x + 1          # 【改：换成题目给的方程 f(x)】

def df(x):
    return np.log(2)*2**(x*x)*2*x - 10  # 【改：换成 f(x) 的一阶导数 f'(x)】

root = newton(f, [0, 2], fprime=df)     # 【改：[0, 2] 换成题目给的初值（要一次求多个根就写多个）】
print('The roots are:', root)
