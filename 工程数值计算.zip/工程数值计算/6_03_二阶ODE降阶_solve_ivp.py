# -*- coding: utf-8 -*-
# =========================================================================
# 6_03  高阶常微分方程降阶为一阶方程组再用 solve_ivp
#       令 y0=y, y1=y', y2=y''，则方程组返回 [y1, y2, …]
#   题目关键词：高阶微分方程 / 二阶常微分方程 / 化为一阶方程组 / 降阶
# =========================================================================

import numpy as np
from scipy.integrate import solve_ivp
import matplotlib.pyplot as plt

def f(t,y):
    return np.array([y[1],y[2],
                     (-2*y[2]-y[1])])                        # 【与上一行合起来是降阶后的方程组，按题目给的方程改】

sol=solve_ivp(f,(0,10),[2,0],t_eval=np.linspace(0,20,1000))  # 【改：(0,10) 换成题目给的 t 区间，[2,0] 换成初值；注意 linspace 的终点要与区间右端一致，这里写成 20 与 10 不符】
plt.plot(sol.t,sol.y[0])
