# -*- coding: utf-8 -*-
# =========================================================================
# 3_04  Jacobi 迭代解线性方程组（迭代框架，供 3_05 调用，本身不用改）
#       x_i(k+1) = ( b_i - Σ(j≠i) a_ij·x_j(k) ) / a_ii；max|x(k+1)-x(k)| < eps 停止
#   题目关键词：Jacobi 迭代 / 雅可比迭代 / 迭代法解线性方程组 / 迭代公式
# =========================================================================
import numpy as np

def jacbi(a, b, x0, eps = 1e-9, max_iter = 100):                        # 【照抄：迭代框架，不用改。要改的题目数据在 3_05 里】
    n = len(x0)
    for n_iter in range(max_iter):
        x = x0.copy()
        for i in range(n):
            x0[i] = (b[i] - np.sum(a[i, 0 : i] * x[0 : i]) -
                     np.sum(a[i, i + 1 : n] * x[i + 1 : n])) / a[i, i]  # 【与上一行合起来是 Jacobi 迭代式，答卷照抄这两行】
        diff = np.max(np.abs(x - x0))
        if diff < eps:
            break
    else:
        print('The accuracy is not achieved')
    return x0, n_iter + 1
