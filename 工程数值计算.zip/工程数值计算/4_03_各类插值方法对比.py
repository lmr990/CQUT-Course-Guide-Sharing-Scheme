# -*- coding: utf-8 -*-
# =========================================================================
# 4_03  三种插值对比：线性 / 三次样条 / 拉格朗日（含作图）
#       节点多时高次拉格朗日会振荡（Runge 现象），线性最稳、三次样条最常用
#   题目关键词：比较各种插值方法 / 三次样条插值 / 线性插值 / 插值曲线作图 / 龙格现象
# =========================================================================
import numpy as np
from scipy import interpolate as interp
import matplotlib.pyplot as plt
from scipy.interpolate import lagrange

# 在0~2π范围内均匀取10个点
x = np.linspace(0, 2 * np.pi, num = 10)                                # 【改：换成题目给的节点 x】
y = np.sin(x)                                                          # 【改：换成节点处的函数值 y】

# 生成1000个加密点，用来绘制插值曲线
x_new = np.linspace(0, 2 * np.pi, num = 1000)

# 线性插值
f1 = interp.interp1d(x, y)                                             # 【线性插值，不用改】
y1 = f1(x_new)

# 三次样条插值
f2 = interp.interp1d(x, y, kind = 'cubic')                             # 【三次样条插值；只要线性插值就把 kind = 'cubic' 删掉】
y2 = f2(x_new)

# 拉格朗日插值
f3 = lagrange(x, y)                                                    # 【拉格朗日插值，不用改】
y3 = f3(x_new)

# 绘图
plt.plot(x, y, 'o', x_new, y1, '--', x_new, y2, '-', x_new, y3, '-.')
plt.legend(['data', 'linear', 'cubic','lagrange'])
