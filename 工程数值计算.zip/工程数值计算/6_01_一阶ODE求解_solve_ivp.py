# -*- coding: utf-8 -*-
# =========================================================================
# 6_01  一阶常微分方程初值问题（solve_ivp）
#       y' = f(t, y)；solve_ivp(f, (t0, tf), [y0], t_eval=…)
#   题目关键词：一阶常微分方程 / 初值问题 / 求微分方程的数值解 / solve_ivp
# =========================================================================
import numpy as np
from scipy.integrate import solve_ivp

def f(t,y):
    return (y*y+2*y-2)/(y+1)                            # 【改：return 后面换成题目给的右端函数 f(t, y)】

sol=solve_ivp(f,(0,2),[2],t_eval=np.linspace(0,2,100))  # 【改：(0,2) 换成题目给的 t 区间，[2] 换成初值 y0，linspace 的端点要跟区间一致】
print(sol.t)
print(sol.y)
