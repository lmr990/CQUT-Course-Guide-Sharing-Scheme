# -*- coding: utf-8 -*-
# =========================================================================
# 5_01  三点拉格朗日求数值微分（供 5_02 / 5_03 / 6_05 调用，本身不用改）
#       先插值再求导：f'(x) ≈ ( L(x+h) - L(x-h) ) / 2h
#   题目关键词：数值微分 / 三点插值求导 / 由数据表求导数 / 插值型求导公式
# =========================================================================
import numpy as np
from lagrange1 import lagrange

def select(x, x_new):                                      # 【不用改：只负责挑出离 x_new 最近的三个节点】
    n = len(x)
    if x_new <= x[1]:
        return 0
    elif x_new >= x[n-2]:
        return n - 3
    else:
        i = np.flatnonzero(x < x_new)[-1]
        if np.abs(x_new - x[i]) < np.abs(x_new - x[i+1]):
            return i - 1
        else:
            return i

def differential(x, y, h, x_new):                          # 【不用改：求导主函数】
    x_left = x_new - h
    i = select(x, x_left)
    y_left = lagrange(x[i:i+3], y[i:i+3], x_left)
    x_right = x_new + h
    i = select(x, x_right)
    y_right = lagrange(x[i:i+3], y[i:i+3], x_right)
    return (y_right - y_left)/2/h                          # 【中心差分公式，答卷照抄这行】
