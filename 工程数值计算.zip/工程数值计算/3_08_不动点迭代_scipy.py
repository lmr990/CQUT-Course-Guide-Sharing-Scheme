# -*- coding: utf-8 -*-
# =========================================================================
# 3_08  不动点迭代解非线性方程组（scipy 版）
#       fixed_point(g, x0, method='iteration')；不写 method 会走 Aitken 加速，有的题会算不出
#   题目关键词：不动点迭代 / 用 scipy 解非线性方程组 / fixed_point
# =========================================================================
import numpy as np
from scipy import optimize as spopt

def g(x):
    g0 = (11 - x[1] * x[1] - x[2]) / 10.0          # 【改：g 的第 1 个分量，用题目给的式子】
    g1 = (18 - x[0] - x[2] * x[2]) / 10.0          # 【改：g 的第 2 个分量】
    g2 = (15 - x[0] * x[0] - x[1]) / 10.0          # 【改：g 的第 3 个分量】
    return np.array([g0, g1, g2])

x0 = np.array([1,1,1])                             # 【改：初值向量】
x2 = spopt.fixed_point(g, x0, method='iteration')  # 【method='iteration' 照抄别删，删了可能算不出结果】
print('Result with iteration:', x2)
